#' Calculate the one-sided sceptical p-value for multiple replications
#' 
#' Computes multiple sceptical p-values based on the effect sizes of the
#' original and the replication study and the corresponding variances.
#' If specified, the p-values are recalibrated.
#' @import stats
#' @param thetao original study estimate 
#' @param seo standard error for original estimate
#' @param thetar replication estimate(s)
#' @param ser standard error(s) for replication estimate(s)
#' @param wi weight for method weighted harmonic chi squared test
#' @param method Either "\code{Stouffer}", "\code{Fisher}", "\code{harmonic}" or "\code{weighted.harmonic}". Defaults to "\code{Stouffer}". If "\code{harmonic}" or "\code{weighted.harmonic}", the original p-value must small than 2^{-n+1} (n: number of replications)
#' @param type Either "\code{nominal}" or "\code{calibrated}". Setting \code{type} to "nominal" corresponds to no recalibration. A recalibration is applied if \code{type} is "calibrated"and the multiple sceptical p-value
#' can be interpreted on the same scale as an ordinary p-value (e.g., a multiple sceptical p-value can be thresholded at the conventional 0.025 level)  
#' @return \code{pScepticalMulti} returns the multiple sceptical p-value.
#' @details \code{pScepticalMulti} is the multi-dimension version of function \code{pSceptical} from Package \code{ReplicationSuccess}.
#' @references
#' Held, L. (2020). A new standard for the analysis and design of replication
#' studies (with discussion). \emph{Journal of the Royal Statistical Society:
#' Series A (Statistics in Society)}, \bold{183}, 431-448.
#' \doi{10.1111/rssa.12493}
#'
#' Held, L., Micheloud, C., Pawel, S. (2021). The assessment of replication success
#' based on relative effect size. \url{https://arxiv.org/abs/2009.07782}
#' 
#' Pawel, S. (2021). Code of sceptical p-value for multiple replication data (two-sided setting). pSecpticalMA.R.
#' @examples
#' ## no recalibration (type = "nominal")
#' pScepticalMulti(2,1,c(3,1),c(1,1),method = "Stouffer",type = "nominal")
#'
#' pScepticalMulti(2,1,c(3,1),c(1,1),method = "Fisher",type = "nominal")
#' 
#' pScepticalMulti(2,1,c(3,1),c(1,1),method = "harmonic",type = "nominal")
#' 
#' pScepticalMulti(2,1,c(3,1),c(1,1),method = "weighted.harmonic",type = "nominal")
#' 
#' ## recalibration 
#' pScepticalMulti(2,1,c(3,1),c(1,1),method = "Stouffer",type = "calibrated")
#'
#' @export
pScepticalMulti <- function (thetao,seo, thetar, ser, wi = 1/ser^2,
														 method = c("Stouffer","Fisher","harmonic", "weighted.harmonic"), 
														 type = c("nominal","calibrated"))
	
{ 
	##options(warn =1)
	## should lead to a valid output
	stopifnot(is.numeric(thetao), # check class
						is.finite(thetao),  # check for NA, Inf, ...
						length(thetao)==1,  # check length, this also excludes NULL
						is.numeric(thetar),
            is.finite(thetar),
											
		
						!is.null(method),
						!is.null(type)
						)
	method <- match.arg(method)
	type <- match.arg(type)
	if (thetao == 0) 
		stop("theta_o must be different from 0" ) 		
	if (!(type %in% c("nominal","calibrated"))) 
		stop("type must be either \"nominal\" or \"calibrated\"")
	if (!(method %in% c("Stouffer","Fisher","harmonic", "weighted.harmonic"))) 
		stop("type must be either \"Stouffer\", \"Fisher\", \"harmonic\" or \"weighted.harmonic\"")
	
	zo <- thetao/seo
	po <- pnorm(q = zo, lower.tail = FALSE)
	df <- length(thetar)
	
	rootStouffer <- function(alpha){
		zalpha <- -qnorm(p = alpha)
		tau2alpha <- seo^2/(zo^2/zalpha^2 - 1)
		sqtau <- sqrt(ser^2 + tau2alpha)
		Tbox <- sum(thetar/sqtau)/sqrt(df)
		(Tbox + qnorm(p = alpha))^2
	} 
	rootFisher <- function(alpha){
		zalpha <- -qnorm(p = alpha) 
		tau2alpha <- seo^2/(zo^2/zalpha^2 - 1)
		sqtau <- sqrt(ser^2 + tau2alpha)
		pbox <- sum(log(pnorm(thetar/sqtau,lower.tail = FALSE)))*(-2)
		(pbox - qchisq(p = alpha, df = 2*df, lower.tail = FALSE))^2
	}
	rootharmonic <- function(alpha){
		zalpha <- -qnorm(p = alpha) 
		tau2alpha <- seo^2/(zo^2/zalpha^2 - 1)
		tbox <- sqrt(df^2/sum((ser^2+tau2alpha)/thetar^2))
		(tbox + qnorm(p = 2^(df-1)*alpha))^2
	}
	rootwharmonic <- function(alpha){
		zalpha <- -qnorm(p = alpha) 
		tau2alpha <- seo^2/(zo^2/zalpha^2 - 1)
		w <- sum(sqrt(wi))
		tbox <- sqrt(w^2/sum(wi*(ser^2+tau2alpha)/thetar^2))
		(tbox + qnorm(p = 2^(df-1)*alpha))^2
	}
	
	rootFun <- switch(method,
										Stouffer=rootStouffer,
										Fisher=rootFisher,
										harmonic=rootharmonic,
										weighted.harmonic=rootwharmonic
	)
	
	ps  <-  if ( !(method %in% c("harmonic", "weighted.harmonic"))) {
		optimize(rootFun, interval =c(ifelse(thetao < 0, 0, po), 1), tol = 1e-30)$minimum
	} 
	else if (method %in% c("harmonic", "weighted.harmonic") && (po <= 1/2^(df-1))) {
		optimize(rootFun, interval = c(po, 1/2^(df-1)), tol = 1e-30)$minimum
	} 
	else {
		warning("Mean harmonic chi^2 test is not available!")
		NA
	}
	### give warnings when minimizing (A - B)^2 did not give 0
	
	if (!is.na(ps) && rootFun(ps) >=0.01){
			warning(paste("p-value solved with residual", sqrt(rootFun(ps)), sep=""))
		}
	
	if (type == "nominal") 
		result <- ps
	if (type == "calibrated") {
		phi <- (sqrt(1+4/df) + 1)/2
		result <- pnorm( q = qnorm(p = ps, lower.tail = FALSE) * sqrt(phi), lower.tail = FALSE)
	}
	return(result)
}

